#!/bin/bash

MSG="Night"

echo "Hello Everyone, Good $MSG"

echo "This is a very good $MSG"

echo "The value of MSG is $MSG"
